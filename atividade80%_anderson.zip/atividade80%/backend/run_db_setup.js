const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

(async () => {
  try {
    const conn = await mysql.createConnection({
      host: '127.0.0.1',
      user: 'root',
      password: '',
      multipleStatements: true,
    });

    console.log('Conectado ao MySQL como root (sem senha) — executando setup...');

    await conn.query("CREATE DATABASE IF NOT EXISTS clinica DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    await conn.query("CREATE USER IF NOT EXISTS 'clinica_user'@'localhost' IDENTIFIED BY 'SenhaForte123!';");
    await conn.query("GRANT ALL PRIVILEGES ON clinica.* TO 'clinica_user'@'localhost';");
    await conn.query("FLUSH PRIVILEGES;");

    // schema_mysql.sql está na raiz do projeto (um nível acima de /backend)
    const schemaPath = path.join(__dirname, '..', 'schema_mysql.sql');
    if (fs.existsSync(schemaPath)) {
      const sql = fs.readFileSync(schemaPath, 'utf8');
      await conn.query(sql);
      console.log('schema_mysql.sql importado com sucesso');
    } else {
      console.warn('schema_mysql.sql não encontrado em', schemaPath);
    }

    await conn.end();
    console.log('Setup concluído');
    process.exit(0);
  } catch (err) {
    console.error('Erro durante setup do banco:', err.message || err);
    process.exit(1);
  }
})();
