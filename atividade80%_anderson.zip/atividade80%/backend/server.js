const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'clinica',
  waitForConnections: true,
  connectionLimit: 10,
});

// Ensure profissionais table has a criado_por (FK) and criado_por_nome (string) columns for audit (add if missing)
(async () => {
  try {
    const dbName = process.env.DB_NAME || 'clinica';
    const [rows] = await pool.query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'profissionais' AND COLUMN_NAME = 'criado_por'", [dbName]);
    if (!rows || rows.length === 0) {
      console.log('Adicionando coluna criado_por em profissionais...');
      await pool.query("ALTER TABLE profissionais ADD COLUMN criado_por INT NULL, ADD CONSTRAINT fk_prof_criado_por FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL");
      console.log('Coluna criado_por adicionada');
    }
    const [rowsNome] = await pool.query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'profissionais' AND COLUMN_NAME = 'criado_por_nome'", [dbName]);
    if (!rowsNome || rowsNome.length === 0) {
      console.log('Adicionando coluna criado_por_nome em profissionais...');
      await pool.query("ALTER TABLE profissionais ADD COLUMN criado_por_nome VARCHAR(255) NULL");
      console.log('Coluna criado_por_nome adicionada');
    }
  } catch (err) {
    console.warn('Aviso ao checar/alterar profissionais (colunas):', err.message || err);
  }
})();

// Simple health check
app.get('/api/health', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 as ok');
    res.json({ ok: true });
  } catch (err) {
    console.error('DB health error', err);
    res.status(500).json({ ok: false, error: String(err) });
  }
});

app.get('/api/especialidades', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, nome FROM especialidades ORDER BY nome');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar especialidades' });
  }
});

app.get('/api/pacientes', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT p.id, u.nome, u.email, p.cpf, p.data_nascimento AS dataNascimento
       FROM pacientes p
       JOIN usuarios u ON u.id = p.usuario_id`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar pacientes' });
  }
});

app.get('/api/profissionais', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT pr.id, u.nome, u.email, pr.registro, e.nome AS especialidade, pr.criado_por, COALESCE(uc.nome, pr.criado_por_nome) AS criado_por_nome
       FROM profissionais pr
       JOIN usuarios u ON u.id = pr.usuario_id
       LEFT JOIN especialidades e ON e.id = pr.especialidade_id
       LEFT JOIN usuarios uc ON uc.id = pr.criado_por`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar profissionais' });
  }
});

app.get('/api/consultas', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT c.id, c.data_consulta AS dataConsulta, c.horario, c.situacao, c.observacao,
              p.id AS paciente_id, pu.nome AS paciente_nome,
              prf.id AS profissional_id, prf_u.nome AS profissional_nome,
              e.nome AS especialidade
       FROM consultas c
       JOIN pacientes p ON p.id = c.paciente_id
       JOIN usuarios pu ON pu.id = p.usuario_id
       JOIN profissionais prf ON prf.id = c.profissional_id
       JOIN usuarios prf_u ON prf_u.id = prf.usuario_id
       LEFT JOIN especialidades e ON e.id = c.especialidade_id`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar consultas' });
  }
});

app.post('/api/consultas', async (req, res) => {
  try {
    // Accept both snake_case (from API clients) and camelCase (from frontend)
    const body = req.body || {};
    const paciente_id = body.paciente_id || body.pacienteId || body.pacienteId;
    const profissional_id = body.profissional_id || body.profissionalId || body.profissionalId;
    const especialidade_id = body.especialidade_id || body.especialidadeId || body.especialidade || null;
    const data_consulta = body.data_consulta || body.dataConsulta || null;
    const horario = body.horario || body.time || null;
    const situacao = body.situacao || body.status || 'Agendada';
    const observacao = body.observacao || body.observation || null;

    // Basic validation
    if (!paciente_id || !profissional_id || !data_consulta || !horario) {
      return res.status(400).json({ error: 'Dados incompletos. paciente_id, profissional_id, data_consulta e horario são obrigatórios.' });
    }

    const [result] = await pool.query(
      `INSERT INTO consultas (paciente_id, profissional_id, especialidade_id, data_consulta, horario, situacao, observacao)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [paciente_id, profissional_id, especialidade_id || null, data_consulta, horario, situacao || 'Agendada', observacao || null]
    );

    // Return created object info so frontend can map predictably
    res.status(201).json({ id: result.insertId, paciente_id, profissional_id, especialidade_id, data_consulta, horario, situacao, observacao });
  } catch (err) {
    console.error('Erro ao criar consulta:', err);
    // Return error details for debugging (safe in dev). In production, avoid exposing DB errors.
    res.status(500).json({ error: 'Erro ao criar consulta', details: String(err.message) });
  }
});

// Endpoint para criar usuários (com inserção automática em pacientes ou profissionais quando aplicável)
app.post('/api/usuarios', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { perfil, nome, email, senha, telefone, cpf, data_nascimento, registro, especialidade, criado_por } = req.body;

    // Verifica email duplicado
    const [[existing]] = await conn.query('SELECT id FROM usuarios WHERE email = ? LIMIT 1', [email]);
    if (existing) {
      conn.release();
      return res.status(400).json({ error: 'E-mail já cadastrado' });
    }

    // Inserir usuário (senha armazenada diretamente em senha_hash neste exemplo)
    const [r] = await conn.query('INSERT INTO usuarios (perfil, nome, email, senha_hash, telefone) VALUES (?, ?, ?, ?, ?)', [perfil, nome, email, senha || '', telefone || null]);
    const userId = r.insertId;

    if (perfil === 'paciente') {
      await conn.query('INSERT INTO pacientes (usuario_id, cpf, data_nascimento) VALUES (?, ?, ?)', [userId, cpf || null, data_nascimento || null]);
    } else if (perfil === 'profissional') {
      // resolve especialidade para id se nome for informado
      let especialidadeId = null;
      if (especialidade) {
        const [espRows] = await conn.query('SELECT id FROM especialidades WHERE nome = ? LIMIT 1', [especialidade]);
        if (espRows && espRows.length) especialidadeId = espRows[0].id;
      }
      // verify criado_por corresponds to an existing usuario id — if not, set to null to avoid FK error
      let criadoPorId = null;
      if (criado_por) {
        const [userCheck] = await conn.query('SELECT id FROM usuarios WHERE id = ? LIMIT 1', [criado_por]);
        if (userCheck && userCheck.length) criadoPorId = criado_por;
      }
      // also accept criado_por_nome (string) to record creator name when numeric FK is not available
    const criadoPorNome = req.body.criado_por_nome || null;
    await conn.query('INSERT INTO profissionais (usuario_id, registro, especialidade_id, criado_por, criado_por_nome) VALUES (?, ?, ?, ?, ?)', [userId, registro || null, especialidadeId, criadoPorId, criadoPorNome]);
    }

    conn.release();
    res.status(201).json({ id: userId });
  } catch (err) {
    conn.release();
    console.error('Erro ao criar usuario:', err);
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
});

// Serve frontend static files from the project folder (avoids CORS during dev)
const path = require('path');
const fs = require('fs');
// The frontend files live in the repository root (one level above backend). Use project root as static folder.
const frontendPath = path.join(__dirname, '..');
// If the frontend exists in the expected folder, serve it so the app can be opened at http://localhost:PORT
if (fs.existsSync(frontendPath) && fs.existsSync(path.join(frontendPath, 'index.html'))) {
  app.use('/', express.static(frontendPath));
  console.log('Servindo frontend estático de:', frontendPath);
} else {
  console.log('Pasta de frontend não encontrada em:', frontendPath);
}

const port = process.env.PORT || 8080;
app.listen(port, () => console.log('API rodando na porta', port));
