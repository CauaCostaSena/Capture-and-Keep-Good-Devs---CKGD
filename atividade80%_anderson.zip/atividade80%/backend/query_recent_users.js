const mysql = require('mysql2/promise');

(async () => {
  try {
    const conn = await mysql.createConnection({
      host: '127.0.0.1',
      user: 'clinica_user',
      password: 'SenhaForte123!',
      database: 'clinica',
      port: 3306,
    });

    const [rows] = await conn.query("SELECT id, perfil, nome, email, criado_em FROM usuarios ORDER BY id DESC LIMIT 20");
    console.table(rows);
    await conn.end();
    process.exit(0);
  } catch (err) {
    console.error('Erro ao consultar:', err.message || err);
    process.exit(1);
  }
})();
