const mysql = require('mysql2/promise');

(async () => {
  try {
    const conn = await mysql.createConnection({
      host: '127.0.0.1',
      user: 'clinica_user',
      password: 'SenhaForte123!',
      database: 'clinica',
      port: 3306,
    });

    console.log('Conectado ao MySQL como clinica_user');

    const queries = [
      { name: 'tables', sql: "SHOW TABLES" },
      { name: 'count_especialidades', sql: "SELECT COUNT(*) AS cnt FROM especialidades" },
      { name: 'count_usuarios', sql: "SELECT COUNT(*) AS cnt FROM usuarios" },
      { name: 'count_pacientes', sql: "SELECT COUNT(*) AS cnt FROM pacientes" },
      { name: 'count_profissionais', sql: "SELECT COUNT(*) AS cnt FROM profissionais" },
      { name: 'count_consultas', sql: "SELECT COUNT(*) AS cnt FROM consultas" },
      { name: 'especialidades_sample', sql: "SELECT id, nome FROM especialidades ORDER BY id LIMIT 50" },
      { name: 'usuarios_sample', sql: "SELECT id, perfil, nome, email FROM usuarios ORDER BY id LIMIT 10" },
      { name: 'consultas_sample', sql: "SELECT id, paciente_id, profissional_id, data_consulta, horario, situacao FROM consultas ORDER BY id LIMIT 10" }
    ];

    for (const q of queries) {
      const [rows] = await conn.query(q.sql);
      console.log('\n== ' + q.name + ' ==');
      console.table(rows);
    }

    await conn.end();
    process.exit(0);
  } catch (err) {
    console.error('Erro ao consultar o banco:', err.message || err);
    process.exit(1);
  }
})();
