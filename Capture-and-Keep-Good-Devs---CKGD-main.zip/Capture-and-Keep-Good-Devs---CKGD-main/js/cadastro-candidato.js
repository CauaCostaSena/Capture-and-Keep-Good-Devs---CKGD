// Oásis não possui cadastro manual de candidatos: os perfis vêm do GitHub.
window.location.replace("cadastro.html");
