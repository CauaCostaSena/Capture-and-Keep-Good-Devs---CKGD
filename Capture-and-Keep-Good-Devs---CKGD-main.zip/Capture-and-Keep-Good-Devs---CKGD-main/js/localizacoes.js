const OasisLocalizacoes = (() => {
    const dados = {
        "Brasil": {
            "Acre": ["Rio Branco"], "Alagoas": ["Maceió"], "Amapá": ["Macapá"], "Amazonas": ["Manaus"],
            "Bahia": ["Salvador", "Feira de Santana"], "Ceará": ["Fortaleza"], "Distrito Federal": ["Brasília"],
            "Espírito Santo": ["Vitória"], "Goiás": ["Goiânia"], "Maranhão": ["São Luís"],
            "Mato Grosso": ["Cuiabá"], "Mato Grosso do Sul": ["Campo Grande"], "Minas Gerais": ["Belo Horizonte"],
            "Pará": ["Belém"], "Paraíba": ["João Pessoa"], "Paraná": ["Curitiba"],
            "Pernambuco": ["Recife"], "Piauí": ["Teresina"], "Rio de Janeiro": ["Rio de Janeiro", "Niterói"],
            "Rio Grande do Norte": ["Natal"], "Rio Grande do Sul": ["Porto Alegre"], "Rondônia": ["Porto Velho"],
            "Roraima": ["Boa Vista"], "Santa Catarina": ["Florianópolis"], "São Paulo": ["São Paulo", "Campinas", "Santos"],
            "Sergipe": ["Aracaju"], "Tocantins": ["Palmas"]
        },
        "Argentina": { "Buenos Aires": ["Buenos Aires", "La Plata"], "Córdoba": ["Córdoba"], "Santa Fe": ["Rosario"], "Mendoza": ["Mendoza"] },
        "Chile": { "Santiago Metropolitan": ["Santiago"], "Valparaíso": ["Valparaíso"], "Biobío": ["Concepción"] },
        "Colômbia": { "Bogotá D.C.": ["Bogotá"], "Antioquia": ["Medellín"], "Valle del Cauca": ["Cali"] },
        "Peru": { "Lima": ["Lima"], "Arequipa": ["Arequipa"], "Cusco": ["Cusco"] },
        "Estados Unidos": { "California": ["Los Angeles", "San Francisco", "San Diego"], "New York": ["New York"], "Texas": ["Houston", "Austin", "Dallas"], "Florida": ["Miami", "Orlando"], "Washington": ["Seattle"] },
        "Canadá": { "Ontario": ["Toronto", "Ottawa"], "Québec": ["Montréal", "Québec"], "British Columbia": ["Vancouver"], "Alberta": ["Calgary", "Edmonton"] },
        "México": { "Ciudad de México": ["Cidade do México"], "Jalisco": ["Guadalajara"], "Nuevo León": ["Monterrey"], "Yucatán": ["Mérida"] },
        "Portugal": { "Lisboa": ["Lisboa"], "Porto": ["Porto"], "Braga": ["Braga"] },
        "Espanha": { "Madrid": ["Madrid"], "Catalunha": ["Barcelona"], "Andaluzia": ["Sevilha", "Málaga"] },
        "França": { "Île-de-France": ["Paris"], "Auvergne-Rhône-Alpes": ["Lyon"], "Provence-Alpes-Côte d'Azur": ["Marselha"] },
        "Alemanha": { "Berlim": ["Berlim"], "Baviera": ["Munique"], "Hamburgo": ["Hamburgo"] },
        "Itália": { "Lácio": ["Roma"], "Lombardia": ["Milão"], "Vêneto": ["Veneza"] },
        "Reino Unido": { "Inglaterra": ["Londres", "Manchester"], "Escócia": ["Edimburgo", "Glasgow"], "País de Gales": ["Cardiff"] },
        "Países Baixos": { "Holanda do Norte": ["Amsterdã"], "Holanda do Sul": ["Roterdã"], "Utrecht": ["Utrecht"] },
        "Suíça": { "Zurique": ["Zurique"], "Genebra": ["Genebra"], "Vaud": ["Lausana"] }
    };

    function preencherOpcoes(select, opcoes, placeholder) {
        select.innerHTML = `<option value="">${placeholder}</option>`;
        opcoes.forEach(opcao => select.add(new Option(opcao, opcao)));
        select.disabled = opcoes.length === 0;
    }

    return {
        preencherPaises(select) { preencherOpcoes(select, Object.keys(dados), "Selecione um país"); },
        estadosDe(pais) { return Object.keys(dados[pais] || {}); },
        cidadesDe(pais, estado) { return (dados[pais] || {})[estado] || []; },
        preencherOpcoes
    };
})();
