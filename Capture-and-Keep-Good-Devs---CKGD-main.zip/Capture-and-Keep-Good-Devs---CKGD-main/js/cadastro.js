const form = document.getElementById("form-cadastro");
const selectPlano = document.getElementById("input-plano");
const botaoFinalizar = document.getElementById("btn-finalizar-cadastro");
const selectPais = document.getElementById("input-pais");
const selectEstado = document.getElementById("input-estado");
const selectCidade = document.getElementById("input-cidade");
const inputCep = document.getElementById("input-cep");
const inputBairro = document.getElementById("input-bairro");
const inputEndereco = document.getElementById("input-endereco");
const cepStatus = document.getElementById("cep-status");

const estadosBrasilPorUf = {
    AC: "Acre", AL: "Alagoas", AP: "Amapá", AM: "Amazonas", BA: "Bahia", CE: "Ceará",
    DF: "Distrito Federal", ES: "Espírito Santo", GO: "Goiás", MA: "Maranhão", MT: "Mato Grosso",
    MS: "Mato Grosso do Sul", MG: "Minas Gerais", PA: "Pará", PB: "Paraíba", PR: "Paraná",
    PE: "Pernambuco", PI: "Piauí", RJ: "Rio de Janeiro", RN: "Rio Grande do Norte", RS: "Rio Grande do Sul",
    RO: "Rondônia", RR: "Roraima", SC: "Santa Catarina", SP: "São Paulo", SE: "Sergipe", TO: "Tocantins"
};

OasisLocalizacoes.preencherPaises(selectPais);
selectPais.addEventListener("change", () => {
    OasisLocalizacoes.preencherOpcoes(selectEstado, OasisLocalizacoes.estadosDe(selectPais.value), "Selecione um estado/província");
    OasisLocalizacoes.preencherOpcoes(selectCidade, [], "Selecione primeiro o estado");
});
selectEstado.addEventListener("change", () => {
    OasisLocalizacoes.preencherOpcoes(selectCidade, OasisLocalizacoes.cidadesDe(selectPais.value, selectEstado.value), "Selecione uma cidade");
});

inputCep.addEventListener("input", () => {
    inputCep.value = inputCep.value.replace(/\D/g, "").slice(0, 8);
    cepStatus.textContent = "";
});

inputCep.addEventListener("blur", async () => {
    const cep = inputCep.value;
    if (cep.length !== 8) return;
    if (selectPais.value !== "Brasil") {
        cepStatus.textContent = "A consulta automática de CEP está disponível para o Brasil.";
        return;
    }

    cepStatus.textContent = "Consultando CEP...";
    try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const endereco = await response.json();
        if (!response.ok || endereco.erro) throw new Error("CEP não encontrado.");

        inputBairro.value = endereco.bairro || "";
        inputEndereco.value = endereco.logradouro || "";

        const estado = estadosBrasilPorUf[endereco.uf];
        if (estado) {
            selectEstado.innerHTML = "";
            selectEstado.add(new Option(estado, estado, true, true));
            selectEstado.disabled = false;
            OasisLocalizacoes.preencherOpcoes(selectCidade, OasisLocalizacoes.cidadesDe("Brasil", estado), "Selecione uma cidade");
            const cidade = [...selectCidade.options].find(option => option.value.toLowerCase() === endereco.localidade.toLowerCase());
            if (cidade) cidade.selected = true;
        }
        cepStatus.textContent = "Endereço preenchido pelo CEP.";
    } catch (error) {
        inputBairro.value = "";
        inputEndereco.value = "";
        cepStatus.textContent = error.message;
    }
});

// Se já existe sessão ativa, vai direto para a home
if (OasisAPI.isAutenticado()) {
    window.location.href = "home.html";
}

async function carregarPlanos() {
    try {
        const planos = await OasisAPI.listarPlanos();
        selectPlano.innerHTML = "";
        planos.forEach(plano => {
            const option = document.createElement("option");
            option.value = plano.idPlano;
            const preco = Number(plano.precoPlano) === 0 ? "Gratuito" : `R$ ${Number(plano.precoPlano).toFixed(2)}/${plano.periodicidade === "MENSAL" ? "mês" : "ano"}`;
            option.textContent = `${plano.nomePlano} — ${preco}`;
            selectPlano.appendChild(option);
        });
    } catch (err) {
        selectPlano.innerHTML = '<option value="">Não foi possível carregar os planos</option>';
    }
}

carregarPlanos();

form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const payload = {
        nomeEmpresa: document.getElementById("input-nome-empresa").value.trim(),
        cnpj: document.getElementById("input-cnpj").value,
        email: document.getElementById("input-email").value.trim(),
        senha: document.getElementById("input-senha").value,
        pais: document.getElementById("input-pais").value.trim(),
        estado: document.getElementById("input-estado").value.trim(),
        cidade: document.getElementById("input-cidade").value.trim(),
        bairro: document.getElementById("input-bairro").value.trim(),
        endereco: document.getElementById("input-endereco").value.trim(),
        idPlano: selectPlano.value ? Number(selectPlano.value) : null
    };

    if (payload.cnpj.length !== 14) {
        alert("O CNPJ deve conter exatamente 14 dígitos numéricos.");
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/.test(payload.email)) {
        alert("Informe um e-mail com domínio válido, como nome@gmail.com.");
        return;
    }

    botaoFinalizar.disabled = true;
    botaoFinalizar.textContent = "Cadastrando...";

    try {
        const auth = await OasisAPI.cadastrar(payload);
        OasisAPI.salvarSessao(auth);
        window.location.href = "home.html";
    } catch (err) {
        alert(err.message);
    } finally {
        botaoFinalizar.disabled = false;
        botaoFinalizar.textContent = "Finalizar Cadastro";
    }
});

document.getElementById("input-cnpj").addEventListener("input", (event) => {
    event.target.value = event.target.value.replace(/\D/g, "").slice(0, 14);
});
