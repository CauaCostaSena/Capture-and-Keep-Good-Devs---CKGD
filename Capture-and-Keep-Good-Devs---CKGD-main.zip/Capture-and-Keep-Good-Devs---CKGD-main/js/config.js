OasisAPI.exigirAutenticacaoEmpresa();

const fotoPreview = document.getElementById("foto-preview");
const inputFoto = document.getElementById("input-foto");
const btnAlterarFoto = document.getElementById("btn-alterar-foto");

function formatarTelefone(valor) {
    const numeros = (valor || "").replace(/\D/g, "").slice(0, 11);
    if (numeros.length !== 11) return numeros;
    return `(${numeros.slice(0, 2)}) ${numeros.slice(2, 7)}-${numeros.slice(7)}`;
}

function aplicarDadosEmpresa(empresa) {
    document.getElementById("company-name").textContent = empresa.nomeEmpresa;
    document.getElementById("company-location").textContent =
        [empresa.cidade, empresa.estado, empresa.pais].filter(Boolean).join(", ");
    OasisAPI.aplicarLogo(document.getElementById("company-logo"), empresa);
    OasisAPI.aplicarLogo(fotoPreview, empresa);

    document.querySelector('.item-editable[data-field="nomeEmpresa"] [data-display]').textContent = empresa.nomeEmpresa;
    document.getElementById("item-localidade").textContent =
        [empresa.cidade, empresa.estado, empresa.pais].filter(Boolean).join(", ") || "Não informado";
    document.getElementById("item-plano").textContent = empresa.nomePlano || "—";
    document.getElementById("item-email").textContent = empresa.email;
    document.querySelector('.item-editable[data-field="telefone"] [data-display]').textContent = empresa.telefone ? formatarTelefone(empresa.telefone) : "Não informado";
}

async function carregarDados() {
    try {
        const empresa = await OasisAPI.meusDados();
        aplicarDadosEmpresa(empresa);
    } catch (err) {
        document.getElementById("company-name").textContent = OasisAPI.nomeEmpresaLogada() || "Minha Empresa";
    }
}

// --- Foto de perfil ---
btnAlterarFoto.addEventListener("click", () => inputFoto.click());

inputFoto.addEventListener("change", async () => {
    const arquivo = inputFoto.files[0];
    if (!arquivo) return;

    btnAlterarFoto.disabled = true;
    btnAlterarFoto.textContent = "Enviando...";

    try {
        const empresa = await OasisAPI.atualizarFoto(arquivo);
        aplicarDadosEmpresa(empresa);
    } catch (err) {
        alert(err.message);
    } finally {
        btnAlterarFoto.disabled = false;
        btnAlterarFoto.textContent = "Alterar";
        inputFoto.value = "";
    }
});

// --- Itens editáveis (nome da empresa, telefone) ---
function configurarItemEditavel(item) {
    const field = item.dataset.field;
    const display = item.querySelector("[data-display]");
    const input = item.querySelector("[data-input]");
    const btnEdit = item.querySelector('[data-action="edit"]');
    const btnSave = item.querySelector('[data-action="save"]');
    const btnCancel = item.querySelector('[data-action="cancel"]');

    function entrarEmEdicao() {
        const valorAtual = display.textContent;
        input.value = field === "telefone"
            ? (valorAtual === "Não informado" ? "" : formatarTelefone(valorAtual))
            : ((valorAtual === "Não informado" || valorAtual === "—") ? "" : valorAtual);
        display.hidden = true;
        input.hidden = false;
        btnEdit.hidden = true;
        btnSave.hidden = false;
        btnCancel.hidden = false;
        input.focus();
    }

    function sairDaEdicao() {
        display.hidden = false;
        input.hidden = true;
        btnEdit.hidden = false;
        btnSave.hidden = true;
        btnCancel.hidden = true;
    }

    async function salvar() {
        const novoValor = field === "telefone"
            ? input.value.replace(/\D/g, "").slice(0, 11)
            : input.value.trim();

        if (field === "nomeEmpresa" && !novoValor) {
            alert("O nome da empresa não pode ficar em branco.");
            return;
        }
        if (field === "telefone" && novoValor && novoValor.length !== 11) {
            alert("O telefone deve estar no formato (00) 00000-0000.");
            return;
        }

        btnSave.disabled = true;
        try {
            const empresa = await OasisAPI.atualizarPerfil({ [field]: novoValor });
            aplicarDadosEmpresa(empresa);
            sairDaEdicao();
        } catch (err) {
            alert(err.message);
        } finally {
            btnSave.disabled = false;
        }
    }

    btnEdit.addEventListener("click", entrarEmEdicao);
    btnCancel.addEventListener("click", sairDaEdicao);
    btnSave.addEventListener("click", salvar);
    if (field === "telefone") {
        input.addEventListener("input", () => {
            input.value = formatarTelefone(input.value);
        });
    }
    input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") salvar();
        if (e.key === "Escape") sairDaEdicao();
    });
}

document.querySelectorAll(".item-editable").forEach(configurarItemEditavel);

document.getElementById("menu-suporte").addEventListener("click", () => {
    OasisSuporte.abrirModal();
});

// --- Alterar senha ---
document.getElementById("menu-alterar-senha").addEventListener("click", () => {
    const overlay = document.createElement("div");
    overlay.className = "oasis-modal-overlay";
    overlay.innerHTML = `
        <div class="oasis-modal-box">
            <h3>Alterar senha</h3>
            <p class="oasis-modal-subtitle">Informe sua senha atual e a nova senha (mínimo 6 caracteres).</p>
            <div class="oasis-modal-field">
                <label for="senha-atual">Senha atual</label>
                <input type="password" id="senha-atual" autocomplete="current-password">
            </div>
            <div class="oasis-modal-field">
                <label for="senha-nova">Nova senha</label>
                <input type="password" id="senha-nova" autocomplete="new-password" minlength="6">
            </div>
            <div class="oasis-modal-field">
                <label for="senha-confirmar">Confirmar nova senha</label>
                <input type="password" id="senha-confirmar" autocomplete="new-password" minlength="6">
            </div>
            <p class="oasis-modal-error" id="senha-erro"></p>
            <div class="oasis-modal-actions">
                <button type="button" class="btn btn-secondary" id="senha-cancelar">Cancelar</button>
                <button type="button" class="btn btn-primary" id="senha-salvar">Salvar</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    const inputAtual = overlay.querySelector("#senha-atual");
    const inputNova = overlay.querySelector("#senha-nova");
    const inputConfirmar = overlay.querySelector("#senha-confirmar");
    const erro = overlay.querySelector("#senha-erro");
    const btnSalvar = overlay.querySelector("#senha-salvar");

    function fechar() { overlay.remove(); }

    overlay.addEventListener("click", (e) => { if (e.target === overlay) fechar(); });
    overlay.querySelector("#senha-cancelar").addEventListener("click", fechar);

    btnSalvar.addEventListener("click", async () => {
        const senhaAtual = inputAtual.value;
        const novaSenha = inputNova.value;
        const confirmar = inputConfirmar.value;

        if (!senhaAtual || !novaSenha || !confirmar) {
            erro.textContent = "Preencha todos os campos.";
            return;
        }
        if (novaSenha.length < 6) {
            erro.textContent = "A nova senha deve ter ao menos 6 caracteres.";
            return;
        }
        if (novaSenha !== confirmar) {
            erro.textContent = "A confirmação não confere com a nova senha.";
            return;
        }

        erro.textContent = "";
        btnSalvar.disabled = true;
        btnSalvar.textContent = "Salvando...";

        try {
            await OasisAPI.alterarSenha({ senhaAtual, novaSenha });
            overlay.querySelector(".oasis-modal-box").innerHTML = `
                <h3>Senha alterada!</h3>
                <p class="oasis-modal-subtitle">Sua senha foi atualizada com sucesso.</p>
                <div class="oasis-modal-actions">
                    <button type="button" class="btn btn-primary" id="senha-fechar">Fechar</button>
                </div>
            `;
            overlay.querySelector("#senha-fechar").addEventListener("click", fechar);
        } catch (err) {
            erro.textContent = err.message;
            btnSalvar.disabled = false;
            btnSalvar.textContent = "Salvar";
        }
    });

    inputAtual.focus();
});

document.getElementById("menu-assinatura").addEventListener("click", async () => {
    try {
        const planos = await OasisAPI.listarPlanos();
        const lista = planos.map(p => `• ${p.nomePlano} — ${Number(p.precoPlano) === 0 ? "Gratuito" : "R$ " + Number(p.precoPlano).toFixed(2)}`).join("\n");
        alert("Planos disponíveis:\n\n" + lista + "\n\nPara alterar de plano, entre em contato com o suporte.");
    } catch (err) {
        alert("Não foi possível carregar os planos.");
    }
});

document.getElementById("menu-sair").addEventListener("click", () => {
    OasisAPI.encerrarSessao();
    window.location.href = "index.html";
});

carregarDados();
