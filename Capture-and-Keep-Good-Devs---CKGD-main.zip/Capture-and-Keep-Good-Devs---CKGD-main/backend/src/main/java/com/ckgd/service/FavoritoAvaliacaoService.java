package com.ckgd.service;

import com.ckgd.dto.AvaliacaoRequest;
import com.ckgd.dto.AvaliacaoResponse;
import com.ckgd.entity.Candidato;
import com.ckgd.entity.Empresa;
import com.ckgd.entity.EmpresaCandidato;
import com.ckgd.exception.ResourceNotFoundException;
import com.ckgd.repository.CandidatoRepository;
import com.ckgd.repository.EmpresaCandidatoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FavoritoAvaliacaoService {

    private final EmpresaCandidatoRepository empresaCandidatoRepository;
    private final CandidatoRepository candidatoRepository;
    private final EmpresaService empresaService;
    private final GitHubService gitHubService;

    public FavoritoAvaliacaoService(EmpresaCandidatoRepository empresaCandidatoRepository,
                                     CandidatoRepository candidatoRepository,
                                     EmpresaService empresaService,
                                     GitHubService gitHubService) {
        this.empresaCandidatoRepository = empresaCandidatoRepository;
        this.candidatoRepository = candidatoRepository;
        this.empresaService = empresaService;
        this.gitHubService = gitHubService;
    }

    @Transactional
    public AvaliacaoResponse salvarAvaliacao(String cnpj, Long nodeIdCandidato, AvaliacaoRequest req) {
        Empresa empresa = empresaService.buscarPorCnpj(cnpj);
        Candidato candidato = candidatoRepository.findById(nodeIdCandidato)
                .orElseThrow(() -> new ResourceNotFoundException("Candidato não encontrado"));

        if (candidato.getUsername() == null || candidato.getUsername().isBlank()) {
            throw new ResourceNotFoundException("Candidato sem usuário válido no GitHub");
        }
        var githubUsuario = gitHubService.buscarDetalhesUsuario(candidato.getUsername());
        if (githubUsuario == null || githubUsuario.id == null || !githubUsuario.id.equals(candidato.getNodeId())) {
            throw new ResourceNotFoundException("Este candidato não está mais disponível no GitHub");
        }

        EmpresaCandidato vinculo = empresaCandidatoRepository
                .findByEmpresa_CnpjAndCandidato_NodeId(cnpj, nodeIdCandidato)
                .orElseGet(() -> new EmpresaCandidato(empresa, candidato));

        if (req.getFavorito() != null) {
            vinculo.setFavorito(req.getFavorito());
        }
        if (req.getComentario() != null) {
            vinculo.setComentario(req.getComentario());
            vinculo.setDataAvaliacao(LocalDateTime.now());
        }
        if (req.getPrivada() != null) {
            vinculo.setPrivada(req.getPrivada());
        }

        return AvaliacaoResponse.from(empresaCandidatoRepository.save(vinculo));
    }

    @Transactional
    public void removerFavorito(String cnpj, Long nodeIdCandidato) {
        empresaCandidatoRepository.findByEmpresa_CnpjAndCandidato_NodeId(cnpj, nodeIdCandidato)
                .ifPresent(v -> {
                    v.setFavorito(false);
                    empresaCandidatoRepository.save(v);
                });
    }

    @Transactional(readOnly = true)
    public List<AvaliacaoResponse> listarFavoritos(String cnpj) {
        return empresaCandidatoRepository.findByEmpresa_CnpjAndFavoritoTrue(cnpj).stream()
                .map(AvaliacaoResponse::from)
                .toList();
    }
}
