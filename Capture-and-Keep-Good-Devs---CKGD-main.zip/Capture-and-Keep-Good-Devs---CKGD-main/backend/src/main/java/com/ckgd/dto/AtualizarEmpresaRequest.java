package com.ckgd.dto;

import jakarta.validation.constraints.Pattern;

public class AtualizarEmpresaRequest {

    private String nomeEmpresa;
    @Pattern(regexp = "^$|\\d{11}", message = "Telefone deve conter 11 dígitos numéricos")
    private String telefone;

    public String getNomeEmpresa() { return nomeEmpresa; }
    public void setNomeEmpresa(String nomeEmpresa) { this.nomeEmpresa = nomeEmpresa; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
}
