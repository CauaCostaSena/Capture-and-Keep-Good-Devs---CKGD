package com.ckgd.controller;

import com.ckgd.dto.EmpresaResponse;
import com.ckgd.service.EmpresaService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/empresas")
public class EmpresaController {

    private final EmpresaService empresaService;

    public EmpresaController(EmpresaService empresaService) {
        this.empresaService = empresaService;
    }

    @GetMapping("/me")
    public ResponseEntity<EmpresaResponse> meusDados(Authentication authentication) {
        String cnpj = (String) authentication.getPrincipal();
        return ResponseEntity.ok(EmpresaResponse.from(empresaService.buscarPorCnpj(cnpj)));
    }
}
