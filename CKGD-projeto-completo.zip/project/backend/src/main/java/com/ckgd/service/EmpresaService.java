package com.ckgd.service;

import com.ckgd.dto.AuthResponse;
import com.ckgd.dto.CadastroEmpresaRequest;
import com.ckgd.dto.LoginRequest;
import com.ckgd.entity.Empresa;
import com.ckgd.entity.PlanoDeAssinatura;
import com.ckgd.exception.BusinessException;
import com.ckgd.exception.ResourceNotFoundException;
import com.ckgd.repository.EmpresaRepository;
import com.ckgd.repository.PlanoDeAssinaturaRepository;
import com.ckgd.security.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmpresaService {

    private final EmpresaRepository empresaRepository;
    private final PlanoDeAssinaturaRepository planoRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    public EmpresaService(EmpresaRepository empresaRepository,
                           PlanoDeAssinaturaRepository planoRepository,
                           PasswordEncoder passwordEncoder,
                           AuthenticationManager authenticationManager,
                           JwtUtil jwtUtil) {
        this.empresaRepository = empresaRepository;
        this.planoRepository = planoRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    @Transactional
    public AuthResponse cadastrar(CadastroEmpresaRequest req) {
        if (empresaRepository.existsById(req.getCnpj())) {
            throw new BusinessException("Já existe uma empresa cadastrada com este CNPJ");
        }
        if (empresaRepository.existsByEmail(req.getEmail())) {
            throw new BusinessException("Já existe uma empresa cadastrada com este e-mail");
        }

        PlanoDeAssinatura plano;
        if (req.getIdPlano() != null) {
            plano = planoRepository.findById(req.getIdPlano())
                    .orElseThrow(() -> new ResourceNotFoundException("Plano não encontrado"));
        } else {
            // Plano padrão gratuito: assume-se o de menor id (Free), criado no seed inicial
            plano = planoRepository.findAll().stream()
                    .min((a, b) -> a.getIdPlano().compareTo(b.getIdPlano()))
                    .orElseThrow(() -> new BusinessException("Nenhum plano de assinatura cadastrado no sistema"));
        }

        Empresa empresa = new Empresa();
        empresa.setCnpj(req.getCnpj());
        empresa.setNomeEmpresa(req.getNomeEmpresa());
        empresa.setEmail(req.getEmail());
        empresa.setSenha(passwordEncoder.encode(req.getSenha()));
        empresa.setPais(req.getPais());
        empresa.setEstado(req.getEstado());
        empresa.setCidade(req.getCidade());
        empresa.setBairro(req.getBairro());
        empresa.setEndereco(req.getEndereco());
        empresa.setPlano(plano);

        empresa = empresaRepository.save(empresa);

        String token = jwtUtil.gerarToken(empresa.getCnpj());
        return new AuthResponse(token, empresa.getCnpj(), empresa.getNomeEmpresa(), empresa.getEmail());
    }

    public AuthResponse login(LoginRequest req) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.getEmail(), req.getSenha()));
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("E-mail ou senha incorretos");
        }

        Empresa empresa = empresaRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Empresa não encontrada"));

        String token = jwtUtil.gerarToken(empresa.getCnpj());
        return new AuthResponse(token, empresa.getCnpj(), empresa.getNomeEmpresa(), empresa.getEmail());
    }

    public Empresa buscarPorCnpj(String cnpj) {
        return empresaRepository.findById(cnpj)
                .orElseThrow(() -> new ResourceNotFoundException("Empresa não encontrada"));
    }
}
