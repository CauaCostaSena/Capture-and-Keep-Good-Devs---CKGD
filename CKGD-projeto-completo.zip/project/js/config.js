CkgdAPI.exigirAutenticacao();

async function carregarDados() {
    try {
        const empresa = await CkgdAPI.meusDados();
        document.getElementById("company-name").textContent = empresa.nomeEmpresa;
        document.getElementById("company-location").textContent =
            [empresa.cidade, empresa.estado, empresa.pais].filter(Boolean).join(", ");

        document.getElementById("item-nome-empresa").textContent = "Nome da Empresa: " + empresa.nomeEmpresa;
        document.getElementById("item-localidade").textContent = "Localidade: " +
            ([empresa.cidade, empresa.estado, empresa.pais].filter(Boolean).join(", ") || "Não informado");
        document.getElementById("item-plano").textContent = "Plano de Assinatura: " + (empresa.nomePlano || "—");
        document.getElementById("item-email").textContent = "E-mail: " + empresa.email;
    } catch (err) {
        document.getElementById("company-name").textContent = CkgdAPI.nomeEmpresaLogada() || "Minha Empresa";
    }
}

document.getElementById("menu-suporte").addEventListener("click", () => {
    alert("Suporte: contato@ckgd.com — em breve um canal dedicado por aqui.");
});

document.getElementById("menu-assinatura").addEventListener("click", async () => {
    try {
        const planos = await CkgdAPI.listarPlanos();
        const lista = planos.map(p => `• ${p.nomePlano} — ${Number(p.precoPlano) === 0 ? "Gratuito" : "R$ " + Number(p.precoPlano).toFixed(2)}`).join("\n");
        alert("Planos disponíveis:\n\n" + lista + "\n\nPara alterar de plano, entre em contato com o suporte.");
    } catch (err) {
        alert("Não foi possível carregar os planos.");
    }
});

document.getElementById("item-sair").addEventListener("click", () => {
    CkgdAPI.encerrarSessao();
    window.location.href = "index.html";
});

carregarDados();
